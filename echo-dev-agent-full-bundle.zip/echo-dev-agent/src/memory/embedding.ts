import fs from "fs";
import path from "path";
import { RecursiveCharacterTextSplitter } from "langchain/text_splitter";
import { OpenAIEmbeddings } from "langchain/embeddings/openai";
import { Chroma } from "langchain/vectorstores/chroma";
import { config } from "../../agent.config";

export async function embedCodebase(rootDir: string = ".", outDir: string = "./tasks/index") {
  const splitter = new RecursiveCharacterTextSplitter({
    chunkSize: 800,
    chunkOverlap: 100
  });

  const codeFiles: { filePath: string; content: string }[] = [];

  function shouldExclude(p: string): boolean {
    return config.excludePaths.some((exclude) => p.includes(exclude));
  }

  function walk(dir: string) {
    fs.readdirSync(dir).forEach(file => {
      const fullPath = path.join(dir, file);
      if (shouldExclude(fullPath)) return;

      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        walk(fullPath);
      } else if (fullPath.endsWith(".ts") || fullPath.endsWith(".tsx")) {
        const content = fs.readFileSync(fullPath, "utf-8");
        codeFiles.push({ filePath: fullPath, content });
      }
    });
  }

  walk(rootDir);

  const documents = [];
  for (const { filePath, content } of codeFiles) {
    const splits = await splitter.createDocuments([content], [{ type: "file", value: filePath }]);
    documents.push(...splits);
  }

  const embeddings = new OpenAIEmbeddings({ modelName: config.openaiModel });
  const store = await Chroma.fromDocuments(documents, embeddings, {
    collectionName: "echo-memory"
  });

  await store.save(outDir);
  console.log(\`[memory] Embedded \${documents.length} chunks from \${codeFiles.length} files.\`);
}