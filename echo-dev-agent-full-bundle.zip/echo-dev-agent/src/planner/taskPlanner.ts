import { config } from "../../agent.config";
import { OpenAI } from "langchain/llms/openai";
import { loadQAStuffChain } from "langchain/chains";
import { Chroma } from "langchain/vectorstores/chroma";
import { OpenAIEmbeddings } from "langchain/embeddings/openai";
import { Document } from "langchain/document";

export async function planTask(task: string): Promise<string> {
  const model = new OpenAI({ modelName: config.openaiModel, temperature: 0.4 });

  const vectorStore = await Chroma.fromExistingCollection({
    collectionName: "echo-memory",
    embedding: new OpenAIEmbeddings({ modelName: config.openaiModel })
  });

  const chain = loadQAStuffChain(model);

  const relevantDocs: Document[] = await vectorStore.similaritySearch(task, 6);
  const result = await chain.call({
    input_documents: relevantDocs,
    question: `Analyze and plan this dev task for the Echo project: "${task}".
Return a clear, numbered list of steps and include relevant filenames or components.`
  });

  return result.text;
}