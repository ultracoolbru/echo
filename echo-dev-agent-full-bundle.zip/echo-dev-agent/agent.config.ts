export const config = {
  repoOwner: process.env.REPO_OWNER || "ultracoolbru",
  repoName: process.env.REPO_NAME || "echo",
  branchPrefix: "agent-fix/",
  excludePaths: ["node_modules", "dist", "build", ".next"],
  useOpenAI: true,
  openaiModel: "gpt-4o",
  baseBranch: "main"
};